from distutils.core import setup
setup(name='uuid', version='1.30', py_modules=['uuid'],
      description='UUID object and generation functions',
      author='Ka-Ping Yee', author_email='ping@zesty.ca',
      url='http://zesty.ca/python/')
